#!/bin/bash
##############################################################
# File Name: install.sh
# Author: Pan ShaoPeng
# Created Time : 2018-11-13 22:41:04
##############################################################
#1. 目录服务器的sql生成
SCRIPT_DIR=`pwd`
/usr/bin/cp $SCRIPT_DIR/dir_sql $SCRIPT_DIR/tmp/dir_sql_tmp
read -p '请输入使用的域名或IP：' SET_URL
sed -i "s#set_url#$SET_URL#g" $SCRIPT_DIR/tmp/dir_sql_tmp
read -p '域名是否使用特殊端口：[y/n]' PORT_YN
#[[ $SET_PORT = "y" ]] || [[ $SET_PORT = "Y" ]] && sed -i "#set_port#:$SET_PORT#" $SCRIPT_DIR/tmp/dir_sql_tmp
#[[ $SET_PORT = "n" ]] || [[ $SET_PORT = "N" ]] && sed -i "#set_port##" $SCRIPT_DIR/tmp/dir_sql_tmp

[[ $PORT_YN = "y" ]] || [[ $PORT_YN = "Y" ]] && read -p '请输入端口号：' SET_PORT && sed -i "s#set_port#:$SET_PORT#g" $SCRIPT_DIR/tmp/dir_sql_tmp
[[ $PORT_YN = "n" ]] || [[ $PORT_YN = "N" ]] && sed -i "s#set_port##g" $SCRIPT_DIR/tmp/dir_sql_tmp && echo '将使用默认端口！！！'
read -p '
==========
y == 域名前使用https
n == 域名前使用http
是否使用ssl协议 [y/n] :
' SET_HTTP

[[ $SET_HTTP = "y" ]] || [[ $SET_HTTP = "Y" ]] && sed -i "s#set_http#https#g" $SCRIPT_DIR/tmp/dir_sql_tmp
[[ $SET_HTTP = "n" ]] || [[ $SET_HTTP = "N" ]] && sed -i "s#set_http#http#g" $SCRIPT_DIR/tmp/dir_sql_tmp

FILE_CONTEXT=`cat $SCRIPT_DIR/tmp/dir_sql_tmp`
echo "请粘贴以下内容，注意换行符
==============================
server_ip:

$SET_URL
==============================
server_port:

62715
==============================
server_attr_str:

$FILE_CONTEXT
==============================
server_identity:
OK!
==============================
"
rm -f $SCRIPT_DIR/tmp/dir_sql_tmp
